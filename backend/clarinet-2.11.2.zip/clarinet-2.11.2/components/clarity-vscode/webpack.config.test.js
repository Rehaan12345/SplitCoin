// @ts-check
/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-var-requires */
"use-strict";

const configs = require("./webpack.config");

const [clientBrowserConfig] = configs;

module.exports = [clientBrowserConfig];

mod clarinetrc;

pub mod cli;
pub mod dap;
#[cfg(feature = "telemetry")]
mod telemetry;

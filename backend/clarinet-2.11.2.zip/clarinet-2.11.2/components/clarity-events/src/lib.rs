extern crate serde;

#[macro_use]
extern crate serde_json;

pub mod analysis;
